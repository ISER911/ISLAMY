function showSection(id){
document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
document.getElementById(id).classList.add('active');
}

// Load Azkar
fetch('azkar.json')
.then(res=>res.json())
.then(data=>{
  let azkarDiv = document.getElementById('azkar');
  data.forEach(z=>{
    let d=document.createElement('div');
    d.className='card';
    d.innerText=z;
    azkarDiv.appendChild(d);
  });
});

// Load Quran
fetch('quran.json')
.then(res=>res.json())
.then(data=>{
  let quranDiv = document.getElementById('quran');
  data.forEach(a=>{
    let d=document.createElement('div');
    d.className='card';
    d.innerText=a.ayah;
    d.onclick=()=>alert(a.tafsir);
    quranDiv.appendChild(d);
  });
});

// Tasbeeh
let tasbeehDiv = document.getElementById('tasbeeh');
let count = 0;
tasbeehDiv.innerHTML=`<h1 id="count">0</h1><button onclick="inc()">سبّح</button><button onclick="reset()">إعادة</button>`;
function inc(){ count++; document.getElementById('count').innerText=count; }
function reset(){ count=0; document.getElementById('count').innerText=count; }
